TIOL portable build — onnxruntime.dll included next to the exe.
Data: %APPDATA%\com.tiol.desktop
Models auto-download on first run (hf-mirror mirror chain).
